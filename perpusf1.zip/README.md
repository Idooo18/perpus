## Deskripsi Aplikasi
Sistem Informasi Perpustakaan Berbasis Web merupakan sistem yang dapat digunakan untuk mengelola berbagai aktifitas di perpustakaan, mulai dari penyimpanan databuku hingga proses peminjaman.
## DONASI : <a href="https://saweria.co/fauzan1892">https://saweria.co/fauzan1892</a>
### Source Blog :  <a href="https://www.codekop.com/read/source-code-sistem-informasi-perpustakaan-dengan-codeigniter-3-61.html" target="_blank">
https://www.codekop.com/read/source-code-sistem-informasi-perpustakaan-dengan-codeigniter-3-61.html</a>

### Beli versi terbaru nya di link berikut :  <a href="https://www.codekop.com/products/source-code-aplikasi-sistem-informasi-perpustakaan-berbasis-website-5.html" target="_blank">https://www.codekop.com/products/source-code-aplikasi-sistem-informasi-perpustakaan-berbasis-website-5.html</a>

### * Untuk Reuploader Source Code tolong cantumin sumber juga ya, terima kasih :)

##  Framework
* Codeigniter 3.1.11
* Template Admin LTE  Versi 2.4

## Penggunaan Login Akses

<b>Petugas Perpus : </b>
<br/>
Username : anang
<br/>
Password : 123

<b>Anggota Perpus :</b>
<br/>
Username : fauzan
<br/>
Password : 123

** Jika ada issues atau revisi atau menambahkan fitur silahkan pull request di repository ini

## Contributors
<a href="https://fauzan.codekop.com/"> Fauzan Falah</a>

My Blog : <a href="https://www.codekop.com/"> Codekop.com</a>

Gunakan Aplikasi dengan bijak, dan selamat belajar
